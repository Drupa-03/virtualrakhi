const express = require('express');
const router = express.Router();
const db = require('../db');
const { v4: uuidv4 } = require('uuid');

// POST: Generate Rakhi Link
router.post('/generate', (req, res) => {
  const { from_name, to_name } = req.body;
  if (!from_name || !to_name) return res.status(400).json({ error: 'Both names required' });

  const link_id = uuidv4().slice(0, 8);

  const q = 'INSERT INTO rakhi_links (link_id, from_name, to_name) VALUES (?, ?, ?)';
  db.query(q, [link_id, from_name, to_name], (err) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ link: `/view?from=${from_name}&to=${to_name}&id=${link_id}` });
  });
});

// GET: Fetch Details by Link ID
router.get('/view/:link_id', (req, res) => {
  const { link_id } = req.params;
  const q = 'SELECT from_name, to_name FROM rakhi_links WHERE link_id = ?';
  db.query(q, [link_id], (err, results) => {
    if (err) return res.status(500).json({ error: err });
    if (results.length === 0) return res.status(404).json({ error: 'Not found' });
    res.json(results[0]);
  });
});

module.exports = router;
